class i{#e;#t;constructor(e,t){this.#t=e,this.#e=t}destroy(){this.#t.images?.delete(this.#e)}}export{i as ImagePreloaderInstance};
